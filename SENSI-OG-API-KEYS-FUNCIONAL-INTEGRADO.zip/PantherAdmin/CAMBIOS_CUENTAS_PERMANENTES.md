# Cambios solicitados
- Botón para eliminar definitivamente cuentas, con confirmación, mediante DELETE /admin/resellers/:id.
- Precio individual para cuentas existentes mediante PUT /admin/resellers/:id/prices/:days y JSON {"credits": N}.
- Autorización de patches permanente mediante POST /admin/resellers/:id/patches/:patchId con JSON {"permanent": true}; revocación mediante DELETE existente.
- Fondo PantherBlueBackground en la interfaz.

## Servidor

Estos cambios requieren Panther Keygarden 1.1.0 o posterior. La eliminación invalida las sesiones y las keys de la cuenta. Los precios individuales se aplican al generar nuevas keys y los permisos permanentes duran hasta la revocación manual.
