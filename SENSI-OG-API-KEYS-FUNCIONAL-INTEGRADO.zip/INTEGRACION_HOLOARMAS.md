# Integración de HOLOARMAS

- Se agregaron los paquetes `HOLO ROSA.3105`, `HOLO MARI.3105` y `HOLO CELESTE.3105` como recursos del proyecto iOS.
- El menú Patches ahora permite cambiar entre AIMBOT, TEXTURAS y HOLOARMAS.
- TEXTURAS muestra el aviso «Este apartado está en creación».
- HOLOARMAS presenta los tres paquetes con controles que reutilizan la operación existente de aplicar/restaurar y sus audios de activación/desactivación.
- Los paquetes se copian a la biblioteca local de Patches al abrir el menú.

Nota: el proyecto no se compiló en Xcode ni se probó en un dispositivo real en este entorno. Los controles usan el servicio de parches existente; el efecto depende de la compatibilidad y los permisos del dispositivo y del contenido del paquete.
